const lengthEl = document.getElementById('length');
const uppercaseEl = document.getElementById('uppercase');
const lowercaseEl = document.getElementById('lowercase');
const numbersEl = document.getElementById('numbers');
const symbolsEl = document.getElementById('symbols');
const resultEl = document.getElementById('result');
const generateBtn = document.getElementById('generate');
const copyBtn = document.getElementById('copy');
const darkToggleBtn = document.getElementById('toggle-dark'); // dark mode button

const upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lower = "abcdefghijklmnopqrstuvwxyz";
const number = "0123456789";
const symbol = "!@#$%^&*()_+-=[]{}|;:,.<>?/";

function getRandomCharacter(str) {
  return str[Math.floor(Math.random() * str.length)];
}

function generatePassword() {
  const length = +lengthEl.value;
  let characters = '';
  let password = '';

  if (uppercaseEl.checked) characters += upper;
  if (lowercaseEl.checked) characters += lower;
  if (numbersEl.checked) characters += number;
  if (symbolsEl.checked) characters += symbol;

  if (characters === '') {
    resultEl.textContent = 'Please select at least one option!';
    return;
  }

  for (let i = 0; i < length; i++) {
    password += getRandomCharacter(characters);
  }

  // Add animation
  resultEl.classList.remove('animate');
  void resultEl.offsetWidth; // trigger reflow
  resultEl.classList.add('animate');

  resultEl.textContent = password;
}

generateBtn.addEventListener('click', generatePassword);

copyBtn.addEventListener('click', () => {
  const password = resultEl.textContent;
  if (password && password !== '---') {
    navigator.clipboard.writeText(password)
      .then(() => alert('Password copied to clipboard!'));
  }
});

// DARK MODE
darkToggleBtn.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});
